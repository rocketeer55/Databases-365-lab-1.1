// CSC 365, Fall 2018
// Jackson Goyette, Spencer Schurk
// Lab 1-1 test suite

//Test 1
//Testing: R3, R4
//Short command, valid student
//Expected: Berbes,Dick,2,108,Hamer,Gavin

S: Berbes

//Test 2
//Testing: R3, R4
//Long command, valid student
//Expected: Como,Zandra,4,112,Chionchio,Perla

Student: Como

//Test 3
//Testing: R3, R4
//Short command, invalid student
//Expected: no output

S: Yichael

//Test 4
//Testing: 
